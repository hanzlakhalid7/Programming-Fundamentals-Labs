#include<stdio.h>
int main()
{
    char c='0';
    char c1=' ';
    char c2='+',c3='-',c4='*',c5='/',c6='%',c7='$',c8='#',c9='@',c10='!',c11='^',c12='&',c13='(',c14=')',c15='?';
    printf("\nASCII of 0 is %d",c);
    printf("\nASCII of   is %d",c1);
    printf("\nASCII of + is %d",c2);
    printf("\nASCII of - is %d",c3);
    printf("\nASCII of * is %d",c4);
    printf("\nASCII of / is %d",c5);
    printf("\nASCII of %% is %d",c6);
    printf("\nASCII of $ is %d",c7);
    printf("\nASCII of # is %d",c8);
    printf("\nASCII of @ is %d",c9);
    printf("\nASCII of ! is %d",c10);
    printf("\nASCII of ^ is %d",c11);
    printf("\nASCII of & is %d",c12);
    printf("\nASCII of ( is %d",c13);
    printf("\nASCII of ) is %d",c14);
    printf("\nASCII of ? is %d",c15);
}